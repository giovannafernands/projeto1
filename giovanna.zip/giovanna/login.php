<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<div class="banner">   
    <a href="index.php" class="a2"> MENU</a>
    <a href="cadastro.php" class="a2"> CADASTRO</a>
    <a href="login.php" class="a2"> LOGIN</a>
</div>


	 <fieldset>
	 <form method="POST" action="login.php">
<label>Usuário:</label><input type="text" name="usuario" id="usuario"><br>
<label>Senha:</label><input type="password" name="senha" id="senha"><br>
<input type="submit" value="entrar" id="entrar" name="entrar"><br>
	


	 </fieldset>
</body>
</html>