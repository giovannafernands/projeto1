Create table usuarios (
ID Int UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
nome Varchar(30),
usuario Varchar(30),
cpf Varchar(11),
senha Varchar(10),
Primary Key (CPF)) ENGINE = MyISAM;